﻿namespace Ignatenko
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.X = new System.Windows.Forms.Label();
            this.ves = new System.Windows.Forms.TextBox();
            this.raschet = new System.Windows.Forms.Button();
            this.otmena = new System.Windows.Forms.Button();
            this.rost = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.male = new System.Windows.Forms.Button();
            this.fem = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // X
            // 
            this.X.AutoSize = true;
            this.X.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.X.Location = new System.Drawing.Point(489, 266);
            this.X.Name = "X";
            this.X.Size = new System.Drawing.Size(204, 73);
            this.X.TabIndex = 0;
            this.X.Text = "label1";
            // 
            // ves
            // 
            this.ves.Location = new System.Drawing.Point(172, 330);
            this.ves.Multiline = true;
            this.ves.Name = "ves";
            this.ves.Size = new System.Drawing.Size(100, 34);
            this.ves.TabIndex = 2;
            // 
            // raschet
            // 
            this.raschet.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.raschet.Location = new System.Drawing.Point(124, 395);
            this.raschet.Name = "raschet";
            this.raschet.Size = new System.Drawing.Size(75, 23);
            this.raschet.TabIndex = 3;
            this.raschet.Text = "Рассчитать\\";
            this.raschet.UseVisualStyleBackColor = true;
            this.raschet.Click += new System.EventHandler(this.raschet_Click);
            // 
            // otmena
            // 
            this.otmena.Location = new System.Drawing.Point(237, 395);
            this.otmena.Name = "otmena";
            this.otmena.Size = new System.Drawing.Size(75, 23);
            this.otmena.TabIndex = 4;
            this.otmena.Text = "Отмена";
            this.otmena.UseVisualStyleBackColor = true;
            this.otmena.Click += new System.EventHandler(this.otmena_Click);
            // 
            // rost
            // 
            this.rost.Location = new System.Drawing.Point(172, 276);
            this.rost.Multiline = true;
            this.rost.Name = "rost";
            this.rost.Size = new System.Drawing.Size(100, 34);
            this.rost.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(101, 285);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Рост:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(118, 340);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 24);
            this.label3.TabIndex = 7;
            this.label3.Text = "Вес:";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(502, 342);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(191, 45);
            this.trackBar1.TabIndex = 9;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            // 
            // male
            // 
            this.male.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("male.BackgroundImage")));
            this.male.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.male.Location = new System.Drawing.Point(92, 12);
            this.male.Name = "male";
            this.male.Size = new System.Drawing.Size(120, 213);
            this.male.TabIndex = 10;
            this.male.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.male.UseVisualStyleBackColor = true;
            // 
            // fem
            // 
            this.fem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fem.BackgroundImage")));
            this.fem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fem.Location = new System.Drawing.Point(218, 12);
            this.fem.Name = "fem";
            this.fem.Size = new System.Drawing.Size(120, 213);
            this.fem.TabIndex = 11;
            this.fem.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.fem.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.fem);
            this.Controls.Add(this.male);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rost);
            this.Controls.Add(this.otmena);
            this.Controls.Add(this.raschet);
            this.Controls.Add(this.ves);
            this.Controls.Add(this.X);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label X;
        private System.Windows.Forms.TextBox ves;
        private System.Windows.Forms.Button raschet;
        private System.Windows.Forms.Button otmena;
        private System.Windows.Forms.TextBox rost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button male;
        private System.Windows.Forms.Button fem;
    }
}

