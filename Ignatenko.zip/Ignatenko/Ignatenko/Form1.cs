﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ignatenko
{
    public partial class Form1 : Form
    {
        float index;
        float Height;
        float Weight;

        public Form1()
        {
            InitializeComponent();
        }

        private void raschet_Click(object sender, EventArgs e)
        {
            Height = float.Parse(rost.Text);
            Weight = float.Parse(ves.Text);
            Height = Height / 100;
            index = Weight /(Height * Height);
            X.Text = index.ToString("N");
            trackBar1.Value = (int)index;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void otmena_Click(object sender, EventArgs e)
        {
            about m = new about();
            m.Show();
            Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
