﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ignatenko
{
    public partial class Form1 : Form
    {
        float index;
        float Height;
        float Weight;

        public Form1()
        {
            InitializeComponent();
        }

        private void raschet_Click(object sender, EventArgs e)
        {
            Height = float.Parse(rost.Text);
            Weight = float.Parse(ves.Text);
            Height = Height / 100;
            index = Weight /(Height * Height);
            
            if (index < 18.5)
                X.Text = "Недостаточный вес";
            if (index > 18.5 && index < 24.9)
                X.Text = "Здоровый вес";
            if (index > 25 && index < 29.9)
                X.Text = "Избыточный вес";
            if (index > 30)
                X.Text = "Ожирение";
            trackBar1.Value = Convert.ToInt32(index);
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void otmena_Click(object sender, EventArgs e)
        {
            ves.Text = null;
            rost.Text = null;
            X.Text = "00.00";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void ves_TextChanged(object sender, EventArgs e)
        {

        }

        private void rost_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void male_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = male.BackgroundImage;
      
        }

        private void X_Click(object sender, EventArgs e)
        {

        }

        private void fem_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = fem.BackgroundImage;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
