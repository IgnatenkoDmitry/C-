﻿using System.Windows.Controls;

namespace ToursApp
{
    internal static class ManagerHelpers
    {
        public static Frame MainFrame { get; set; }
    }
}